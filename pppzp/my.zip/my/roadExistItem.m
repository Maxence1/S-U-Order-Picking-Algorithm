function [ output_args ] = roadExistItem( order )
%EXISTITEM Summary of this function goes here
%   Detailed explanation goes here


end

